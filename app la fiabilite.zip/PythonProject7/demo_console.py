"""Démo console : valeurs de TEST uniquement (pas des données réelles)."""
from fiabilite.calculations import DonneesInvalidesError, calculer
from fiabilite.models import EquipmentInput

donnees = EquipmentInput(
    nom="Équipement de test",
    nb_defaillances=4,
    temps_fonctionnement_h=2000,
    temps_arret_h=60,
    temps_reparation_h=40,
    duree_mission_h=100,
)

try:
    res = calculer(donnees)
except DonneesInvalidesError as e:
    print("ERREURS :")
    for msg in e.rapport.erreurs:
        print("  -", msg)
else:
    for w in res.avertissements:
        print("⚠", w)
    print()
    for i in res.indicateurs.values():
        print(f"[{i.nature.value}] {i.libelle}")
        print("   ", i.formule)
        print("   ", i.formule_numerique)
        if i.remarque:
            print("    Note :", i.remarque)
    print("\n", res.note_weibull)