"""Contrôle de cohérence des données saisies."""
import math

from .models import EquipmentInput, ValidationReport

SEUIL_FAIBLE_ECHANTILLON = 5  # en dessous, les estimations sont fragiles


def _numerique(x) -> bool:
    return (
        isinstance(x, (int, float))
        and not isinstance(x, bool)
        and math.isfinite(x)
    )


def valider(d: EquipmentInput) -> ValidationReport:
    erreurs: list[str] = []
    avert: list[str] = []

    if not d.nom or not d.nom.strip():
        erreurs.append("Le nom de l'équipement est obligatoire.")

    champs = {
        "Nombre de défaillances": d.nb_defaillances,
        "Temps de fonctionnement": d.temps_fonctionnement_h,
        "Temps d'arrêt": d.temps_arret_h,
        "Temps de réparation": d.temps_reparation_h,
        "Durée de mission": d.duree_mission_h,
    }
    numeriques_ok = True
    for libelle, val in champs.items():
        if not _numerique(val):
            erreurs.append(f"{libelle} : valeur numérique invalide ou manquante.")
            numeriques_ok = False
    if not numeriques_ok:
        return ValidationReport(erreurs, avert)  # comparaisons impossibles

    n = d.nb_defaillances
    top = d.temps_fonctionnement_h
    tarr = d.temps_arret_h
    trep = d.temps_reparation_h
    t = d.duree_mission_h

    # --- Erreurs bloquantes ---
    if n < 0 or not float(n).is_integer():
        erreurs.append("Le nombre de défaillances doit être un entier positif ou nul.")
    if top <= 0:
        erreurs.append("Le temps de fonctionnement doit être strictement positif.")
    if tarr < 0:
        erreurs.append("Le temps d'arrêt ne peut pas être négatif.")
    if trep < 0:
        erreurs.append("Le temps de réparation ne peut pas être négatif.")
    if t <= 0:
        erreurs.append("La durée de mission doit être strictement positive.")
    if tarr >= 0 and trep >= 0 and trep > tarr:
        erreurs.append(
            "Incohérence : le temps de réparation ne peut pas dépasser "
            "le temps d'arrêt total (la réparation est incluse dans l'arrêt)."
        )
    if erreurs:
        return ValidationReport(erreurs, avert)

    # --- Avertissements (calcul possible mais à signaler) ---
    n = int(n)
    if n == 0:
        avert.append(
            "Aucune défaillance : MTBF, MTTR, μ, R(t) et M(t) ne sont pas calculables. "
            "Un λ observé nul ne prouve pas l'absence de défaillance future."
        )
        if trep > 0:
            avert.append(
                "Temps de réparation non nul alors qu'aucune défaillance n'est déclarée "
                "(maintenance préventive ?) : vérifiez la saisie."
            )
    else:
        if trep == 0:
            avert.append(
                "Temps de réparation nul avec des défaillances : MTTR = 0 h et "
                "μ (donc M(t)) non calculable. Vérifiez la saisie."
            )
        if n < SEUIL_FAIBLE_ECHANTILLON:
            avert.append(
                f"Seulement {n} défaillance(s) : les estimations (R(t), M(t)) "
                "sont statistiquement fragiles."
            )
    if t > top:
        avert.append(
            "La durée de mission dépasse le temps de fonctionnement observé : "
            "R(t) est une extrapolation au-delà des données."
        )
    return ValidationReport(erreurs, avert)