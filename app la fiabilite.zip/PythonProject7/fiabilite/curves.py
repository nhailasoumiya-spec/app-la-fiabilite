"""Courbes R(t), A(t), M(t) et graphique comparatif.

Les figures sont des objets matplotlib.figure.Figure (sans pyplot) : elles
s'affichent dans Streamlit et pourront être exportées en PNG pour le PDF.
Chaque fonction figure_* renvoie un tuple (figure | None, message).
Si la figure est None, le message explique pourquoi la courbe est impossible.
"""
import numpy as np
from matplotlib.figure import Figure
from matplotlib.patches import Patch

from .models import Nature, Resultats

N_POINTS = 400
BLEU = "#1f77b4"
ORANGE = "#ff7f0e"
VERT = "#2ca02c"
ROUGE = "#d62728"
GRIS = "#7f7f7f"


# ----------------------------------------------------------- Fonctions math
def fiabilite(lam, t):
    """R(t) = exp(-λ t)."""
    return np.exp(-lam * np.asarray(t, dtype=float))


def maintenabilite(mu, t):
    """M(t) = 1 - exp(-μ t)."""
    return 1.0 - np.exp(-mu * np.asarray(t, dtype=float))


def disponibilite(lam, mu, t):
    """A(t) instantanée, modèle à deux états, A(0) = 1."""
    s = lam + mu
    return mu / s + (lam / s) * np.exp(-s * np.asarray(t, dtype=float))


# ----------------------------------------------------------------- Outils
def _val(res: Resultats, code: str):
    return res.indicateurs[code].valeur


def _verifier_zoom(zoom: float) -> None:
    if not zoom > 0:
        raise ValueError("Le zoom doit être strictement positif.")


def _raison_indisponible(res: Resultats) -> str:
    if res.donnees.nb_defaillances == 0:
        return ("aucune défaillance observée : λ, μ et les estimations "
                "exponentielles ne sont pas calculables.")
    return "temps de réparation nul : μ non calculable (division par zéro)."


def _marque_mission(ax, t_mission: float, y_pct: float, tmax: float) -> None:
    if t_mission <= tmax:
        ax.axvline(t_mission, color=GRIS, ls="--", lw=1)
        ax.scatter([t_mission], [y_pct], color=ROUGE, zorder=5,
                   label=f"Mission t = {t_mission:g} h : {y_pct:.2f} %")
    else:
        ax.plot([], [], " ",
                label=f"Mission t = {t_mission:g} h : {y_pct:.2f} % (hors de l'axe)")


def _habiller(ax, titre, ylabel, tmax, y_bas=0.0, y_haut=102.0) -> None:
    ax.set_title(titre, fontsize=11)
    ax.set_xlabel("Temps t (h)")
    ax.set_ylabel(ylabel)
    ax.set_xlim(0, tmax)
    ax.set_ylim(y_bas, y_haut)
    ax.grid(True, alpha=0.3)
    ax.legend(loc="best", fontsize=8)


# ------------------------------------------------------------- Fiabilité
def figure_fiabilite(res: Resultats, zoom: float = 1.0):
    _verifier_zoom(zoom)
    r_m = _val(res, "R")
    if r_m is None:
        return None, _raison_indisponible(res)

    d = res.donnees
    lam = _val(res, "LAMBDA")
    mtbf = _val(res, "MTBF")
    tmax = 2.0 * d.duree_mission_h * zoom
    t = np.linspace(0, tmax, N_POINTS)

    fig = Figure(figsize=(8, 4.5), layout="constrained")
    ax = fig.subplots()
    ax.plot(t, fiabilite(lam, t) * 100, color=BLEU, lw=2,
            label="R(t) = exp(−λ·t)")
    if mtbf <= tmax:
        ax.axvline(mtbf, color=ORANGE, ls=":", lw=1.5,
                   label=f"MTBF = {mtbf:.6g} h  (R ≈ 36,8 %)")
    if d.temps_fonctionnement_h < tmax:
        ax.axvspan(d.temps_fonctionnement_h, tmax, color=GRIS, alpha=0.12,
                   label="Au-delà du temps observé (extrapolation)")
    _marque_mission(ax, d.duree_mission_h, r_m * 100, tmax)
    _habiller(ax, f"Courbe de fiabilité R(t) : {d.nom.strip()} (estimation, modèle exponentiel)",
              "Fiabilité R(t) (%)", tmax)
    return fig, ""


# ---------------------------------------------------------- Disponibilité
def figure_disponibilite(res: Resultats, zoom: float = 1.0):
    _verifier_zoom(zoom)
    lam, mu = _val(res, "LAMBDA"), _val(res, "MU")
    if not lam or mu is None:
        return None, _raison_indisponible(res)

    d = res.donnees
    a_obs = _val(res, "DISPO_OBS")
    a_inf = mu / (lam + mu)
    tmax = max(d.duree_mission_h, 5.0 / (lam + mu)) * zoom
    t = np.linspace(0, tmax, N_POINTS)
    a_mission = float(disponibilite(lam, mu, d.duree_mission_h))

    fig = Figure(figsize=(8, 4.5), layout="constrained")
    ax = fig.subplots()
    ax.plot(t, disponibilite(lam, mu, t) * 100, color=VERT, lw=2,
            label="A(t) = μ/(λ+μ) + λ/(λ+μ)·exp(−(λ+μ)·t)")
    ax.axhline(a_inf * 100, color=ORANGE, ls="--", lw=1.2,
               label=f"Asymptote = A intrinsèque = {a_inf * 100:.3f} %")
    ax.axhline(a_obs * 100, color=BLEU, ls=":", lw=1.5,
               label=f"Disponibilité observée = {a_obs * 100:.3f} %")
    _marque_mission(ax, d.duree_mission_h, a_mission * 100, tmax)
    bas = max(0.0, min(a_inf, a_obs) * 100 - 2.0)
    _habiller(ax, f"Disponibilité instantanée A(t) : {d.nom.strip()} (estimation, modèle exponentiel)",
              "Disponibilité A(t) (%)", tmax, y_bas=bas, y_haut=100.5)
    return fig, ""


# -------------------------------------------------------- Maintenabilité
def figure_maintenabilite(res: Resultats, zoom: float = 1.0):
    _verifier_zoom(zoom)
    m_m = _val(res, "M")
    mu = _val(res, "MU")
    if m_m is None or mu is None:
        return None, _raison_indisponible(res)

    d = res.donnees
    mttr = _val(res, "MTTR")
    tmax = max(d.duree_mission_h, 5.0 * mttr) * zoom
    t = np.linspace(0, tmax, N_POINTS)

    fig = Figure(figsize=(8, 4.5), layout="constrained")
    ax = fig.subplots()
    ax.plot(t, maintenabilite(mu, t) * 100, color=ORANGE, lw=2,
            label="M(t) = 1 − exp(−μ·t)")
    if mttr <= tmax:
        ax.axvline(mttr, color=BLEU, ls=":", lw=1.5,
                   label=f"MTTR = {mttr:.6g} h  (M ≈ 63,2 %)")
    _marque_mission(ax, d.duree_mission_h, m_m * 100, tmax)
    _habiller(ax, f"Courbe de maintenabilité M(t) : {d.nom.strip()} (estimation, modèle exponentiel)",
              "Maintenabilité M(t) (%)", tmax)
    return fig, ""


# ------------------------------------------------------------- Comparatif
def figure_comparatif(res: Resultats):
    d = res.donnees
    t = f"{d.duree_mission_h:g}"
    items = [
        ("Disponibilité\nobservée", "DISPO_OBS", VERT),
        ("Disponibilité\nintrinsèque", "DISPO_INTR", VERT),
        (f"Fiabilité\nR({t} h)", "R", BLEU),
        (f"Maintenabilité\nM({t} h)", "M", ORANGE),
    ]
    fig = Figure(figsize=(11, 4.8), layout="constrained")
    ax1, ax2 = fig.subplots(1, 2, gridspec_kw={"width_ratios": [2, 1]})

    # --- Panneau 1 : indicateurs sans unité, en %
    for x, (_, code, couleur) in enumerate(items):
        ind = res.indicateurs[code]
        hauteur = 0.0 if ind.valeur is None else ind.valeur * 100
        ax1.bar(x, hauteur, color=couleur, alpha=0.85, edgecolor="white",
                hatch="//" if ind.nature is Nature.ESTIME else None)
        texte = "Non calculable" if ind.valeur is None else f"{hauteur:.2f} %"
        ax1.annotate(texte, (x, hauteur), xytext=(0, 4),
                     textcoords="offset points", ha="center", fontsize=9)
    ax1.set_xticks(range(len(items)))
    ax1.set_xticklabels([n for n, _, _ in items], fontsize=9)
    ax1.set_ylim(0, 125)
    ax1.set_ylabel("Valeur (%)")
    ax1.set_title("Indicateurs sans unité", fontsize=11)
    ax1.grid(True, axis="y", alpha=0.3)
    ax1.legend(handles=[
        Patch(facecolor=GRIS, edgecolor="white", label="Calculé"),
        Patch(facecolor=GRIS, edgecolor="white", hatch="//",
              label="Estimé (modèle exponentiel)"),
    ], loc="upper center", ncol=2, fontsize=8)

    # --- Panneau 2 : MTBF et MTTR en heures
    valeurs = [_val(res, "MTBF"), _val(res, "MTTR")]
    hauteurs = [0.0 if v is None else v for v in valeurs]
    ax2.bar(["MTBF", "MTTR"], hauteurs, color=[BLEU, ORANGE], alpha=0.85)
    positifs = [h for h in hauteurs if h > 0]
    if len(positifs) == 2 and max(positifs) / min(positifs) > 50:
        ax2.set_yscale("log")
        ax2.set_ylim(min(positifs) / 2, max(positifs) * 4)
        ax2.set_title("MTBF et MTTR (échelle logarithmique)", fontsize=11)
    else:
        ax2.set_ylim(0, (max(hauteurs) * 1.2) or 1.0)
        ax2.set_title("MTBF et MTTR", fontsize=11)
    for x, v in enumerate(valeurs):
        texte = "Non calculable" if v is None else f"{v:.6g} h"
        ax2.annotate(texte, (x, hauteurs[x]), xytext=(0, 4),
                     textcoords="offset points", ha="center", fontsize=9)
    ax2.set_ylabel("Heures (h)")
    ax2.grid(True, axis="y", alpha=0.3)

    fig.suptitle(f"Comparaison des indicateurs : {d.nom.strip()}", fontsize=12)
    return fig, ""