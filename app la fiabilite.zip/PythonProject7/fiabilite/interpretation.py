"""Interprétation technique et recommandations de maintenance.

Règles déterministes appliquées aux indicateurs déjà calculés : aucune donnée
n'est inventée. Les seuils de classement sont INDICATIFS (conventions de
pratique, sans valeur normative) et regroupés dans la classe Seuils.
"""
import math
from dataclasses import dataclass, field
from enum import Enum
from typing import Optional

from .models import Resultats
from .validation import SEUIL_FAIBLE_ECHANTILLON

AVERTISSEMENT = (
    "Interprétation et recommandations générées automatiquement par des règles "
    "simples, à partir de seuils indicatifs et des seules valeurs globales saisies. "
    "Elles doivent être validées par le responsable maintenance et ne remplacent "
    "pas une analyse AMDEC ou RCM."
)


class Niveau(str, Enum):
    INFO = "Information"
    BON = "Bon"
    ATTENTION = "Attention"
    CRITIQUE = "Critique"


_RANG = {Niveau.INFO: 0, Niveau.BON: 1, Niveau.ATTENTION: 2, Niveau.CRITIQUE: 3}
ICONES = {Niveau.INFO: "🔵", Niveau.BON: "🟢",
          Niveau.ATTENTION: "🟠", Niveau.CRITIQUE: "🔴"}


class Priorite(int, Enum):
    HAUTE = 1
    MOYENNE = 2
    FAIBLE = 3


LIBELLE_PRIORITE = {
    Priorite.HAUTE: "🔴 Priorité haute",
    Priorite.MOYENNE: "🟠 Priorité moyenne",
    Priorite.FAIBLE: "🟢 Priorité faible",
}


@dataclass(frozen=True)
class Seuils:
    """Seuils indicatifs de classement."""
    dispo_elevee: float = 0.98
    dispo_faible: float = 0.90
    fiab_elevee: float = 0.90
    fiab_faible: float = 0.70
    maint_elevee: float = 0.90
    maint_faible: float = 0.60
    ratio_mttr_mtbf: float = 0.10
    part_arret_hors_reparation: float = 0.30
    n_faible_echantillon: int = SEUIL_FAIBLE_ECHANTILLON

    def lignes(self) -> list[tuple[str, str]]:
        def regle(nom, haut, bas):
            return (nom, f"Bon ≥ {haut:.0%} · Attention de {bas:.0%} à {haut:.0%} "
                         f"· Critique < {bas:.0%}")
        return [
            regle("Disponibilité observée", self.dispo_elevee, self.dispo_faible),
            regle("Fiabilité R(t)", self.fiab_elevee, self.fiab_faible),
            regle("Maintenabilité M(t)", self.maint_elevee, self.maint_faible),
            ("Rapport MTTR / MTBF",
             f"Attention si > {self.ratio_mttr_mtbf:.0%}"),
            ("Part de l'arrêt hors réparation",
             f"Attention si > {self.part_arret_hors_reparation:.0%}"),
            ("Nombre de défaillances",
             f"Échantillon faible si N < {self.n_faible_echantillon}"),
        ]


@dataclass
class Constat:
    code: str
    niveau: Niveau
    titre: str
    texte: str
    nature: str          # "Calculé", "Estimé (modèle exponentiel)" ou "Information"


@dataclass
class Recommandation:
    code: str
    priorite: Priorite
    action: str
    justification: str


@dataclass
class Interpretation:
    niveau_global: Niveau
    synthese: str
    constats: list[Constat] = field(default_factory=list)
    recommandations: list[Recommandation] = field(default_factory=list)
    avertissement: str = AVERTISSEMENT


SYNTHESES = {
    Niveau.CRITIQUE: "Situation préoccupante : au moins un indicateur est sous "
                     "le seuil critique indicatif.",
    Niveau.ATTENTION: "Situation acceptable, avec des points de vigilance.",
    Niveau.BON: "Indicateurs satisfaisants au regard des seuils indicatifs.",
    Niveau.INFO: "Évaluation limitée : les données saisies ne permettent pas "
                 "de qualifier la situation.",
}

ESTIME = "Estimé (modèle exponentiel)"
CALCULE = "Calculé"


def _classer(valeur: float, seuil_haut: float, seuil_bas: float) -> Niveau:
    if valeur >= seuil_haut:
        return Niveau.BON
    if valeur >= seuil_bas:
        return Niveau.ATTENTION
    return Niveau.CRITIQUE


def interpreter(res: Resultats, seuils: Optional[Seuils] = None) -> Interpretation:
    s = seuils or Seuils()
    d = res.donnees
    n = int(d.nb_defaillances)
    top = float(d.temps_fonctionnement_h)
    tarr = float(d.temps_arret_h)
    trep = float(d.temps_reparation_h)
    t = float(d.duree_mission_h)

    val = {code: i.valeur for code, i in res.indicateurs.items()}
    a_obs, a_int = val["DISPO_OBS"], val["DISPO_INTR"]
    r, m, mtbf, mttr = val["R"], val["M"], val["MTBF"], val["MTTR"]

    constats: list[Constat] = []
    recs: list[Recommandation] = []

    # ------------------------------------------------------------ Constats
    # 1. Disponibilité observée
    niv_a = _classer(a_obs, s.dispo_elevee, s.dispo_faible)
    qual_a = {Niveau.BON: "élevée", Niveau.ATTENTION: "moyenne",
              Niveau.CRITIQUE: "faible"}[niv_a]
    constats.append(Constat(
        "DISPO", niv_a, f"Disponibilité {qual_a}",
        f"La disponibilité observée est de {a_obs * 100:.2f} % : l'équipement a "
        f"été à l'arrêt {tarr:g} h sur {top + tarr:g} h observées "
        f"({(1 - a_obs) * 100:.2f} % du temps).",
        CALCULE))

    # 2. Fiabilité sur la mission
    niv_r = None
    if r is not None:
        niv_r = _classer(r, s.fiab_elevee, s.fiab_faible)
        qual_r = {Niveau.BON: "bonne", Niveau.ATTENTION: "modérée",
                  Niveau.CRITIQUE: "faible"}[niv_r]
        constats.append(Constat(
            "FIAB", niv_r, f"Fiabilité sur la mission : {qual_r}",
            f"Sur une mission de {t:g} h, la probabilité de ne subir aucune "
            f"défaillance est estimée à {r * 100:.2f} %, soit un risque estimé de "
            f"{(1 - r) * 100:.2f} % d'au moins une défaillance. La mission "
            f"représente {t / mtbf:.2f} × le MTBF ({mtbf:.6g} h).",
            ESTIME))
    else:
        k = -math.log(0.05)  # ≈ 2,996 : règle des trois
        lam_sup = k / top
        constats.append(Constat(
            "ZERO_DEFAILLANCE", Niveau.INFO, "Aucune défaillance observée",
            f"Aucune défaillance n'est déclarée sur {top:g} h de fonctionnement : "
            "MTBF, MTTR, R(t) et M(t) ne sont pas calculables. Cela ne prouve pas "
            "que l'équipement est sans risque. Sous l'hypothèse d'un taux constant, "
            f"la borne supérieure de λ à 95 % de confiance serait d'environ "
            f"{lam_sup:.6g} 1/h (règle des trois : ≈ 3 / T_fonct), soit un MTBF "
            f"d'au moins ≈ {1 / lam_sup:.6g} h.",
            ESTIME))

    # 3. Maintenabilité
    niv_m = None
    if m is not None:
        niv_m = _classer(m, s.maint_elevee, s.maint_faible)
        qual_m = {Niveau.BON: "bonne", Niveau.ATTENTION: "modérée",
                  Niveau.CRITIQUE: "faible"}[niv_m]
        constats.append(Constat(
            "MAINT", niv_m, f"Maintenabilité : {qual_m}",
            f"Une réparation a une probabilité estimée de {m * 100:.2f} % d'être "
            f"terminée en {t:g} h (MTTR = {mttr:.6g} h). La durée t utilisée est "
            "celle de la mission.",
            ESTIME))
    elif n > 0:
        constats.append(Constat(
            "MAINT", Niveau.INFO, "Maintenabilité non calculable",
            "Le temps de réparation saisi est nul : μ et M(t) ne sont pas "
            "calculables. Vérifiez la saisie.",
            CALCULE))

    # 4. Poids de la réparation dans le cycle
    ratio_haut = False
    if mtbf is not None and mttr is not None and mttr > 0:
        ratio = mttr / mtbf
        ratio_haut = ratio > s.ratio_mttr_mtbf
        constats.append(Constat(
            "RATIO", Niveau.ATTENTION if ratio_haut else Niveau.BON,
            "Poids de la réparation",
            f"Le MTTR représente {ratio * 100:.2f} % du MTBF ({mttr:.6g} h pour "
            f"{mtbf:.6g} h)."
            + (" Une part importante du cycle est consacrée à la réparation."
               if ratio_haut else ""),
            CALCULE))

    # 5. Arrêts hors réparation
    attente_haute = False
    attente = tarr - trep
    part_attente = attente / tarr if tarr > 0 else 0.0
    if tarr > 0 and part_attente > s.part_arret_hors_reparation:
        attente_haute = True
        texte = (f"{attente:g} h d'arrêt sur {tarr:g} h ({part_attente * 100:.1f} %) "
                 "ne correspondent pas à du temps de réparation. Leur nature "
                 "(attente de pièces, diagnostic, organisation, arrêts programmés…) "
                 "n'est pas renseignée et doit être identifiée.")
        if a_int is not None:
            texte += (f" L'écart entre la disponibilité intrinsèque "
                      f"({a_int * 100:.2f} %) et la disponibilité observée "
                      f"({a_obs * 100:.2f} %) provient de ces arrêts.")
        constats.append(Constat("ATTENTE", Niveau.ATTENTION,
                                "Arrêts hors réparation importants", texte, CALCULE))

    # 6. Échantillon
    faible_echantillon = 0 < n < s.n_faible_echantillon
    if faible_echantillon:
        constats.append(Constat(
            "ECHANTILLON", Niveau.ATTENTION, "Échantillon faible",
            f"Seulement {n} défaillance(s) observée(s) : R(t) et M(t) sont "
            "statistiquement fragiles et peuvent changer sensiblement avec de "
            "nouvelles données.",
            "Information"))

    # 7. Extrapolation
    extrapolation = n > 0 and t > top
    if extrapolation:
        constats.append(Constat(
            "EXTRAPOLATION", Niveau.ATTENTION, "Mission au-delà des données",
            f"La mission ({t:g} h) dépasse le temps de fonctionnement observé "
            f"({top:g} h) : R(t) est une extrapolation.",
            "Information"))

    # 8. Weibull
    constats.append(Constat("WEIBULL", Niveau.INFO, "Loi de Weibull non évaluée",
                            res.note_weibull, "Information"))

    # ------------------------------------------------------ Recommandations
    r_crit = niv_r is Niveau.CRITIQUE
    r_att = niv_r is Niveau.ATTENTION
    m_crit = niv_m is Niveau.CRITIQUE
    m_bas = niv_m in (Niveau.ATTENTION, Niveau.CRITIQUE)

    if niv_a is Niveau.CRITIQUE:
        justif = (f"Disponibilité observée de {a_obs * 100:.2f} % "
                  f"({tarr:g} h d'arrêt sur {top + tarr:g} h).")
        if tarr > 0:
            justif += (f" Sur l'arrêt total, {trep / tarr * 100:.0f} % est du temps "
                       f"de réparation et {(tarr - trep) / tarr * 100:.0f} % n'en est pas.")
        recs.append(Recommandation(
            "PRIORISER", Priorite.HAUTE,
            "Classer cet équipement parmi les priorités d'amélioration et agir sur "
            "le levier dominant : fréquence des défaillances, durée de réparation "
            "ou arrêts hors réparation.",
            justif))

    if r_crit or r_att:
        recs.append(Recommandation(
            "ANALYSE_CAUSES", Priorite.HAUTE if r_crit else Priorite.MOYENNE,
            "Analyser les causes des défaillances (analyse des causes racines, "
            "AMDEC) et traiter en priorité les modes de défaillance les plus "
            "fréquents ou les plus coûteux. Ces modes ne figurent pas dans la "
            "saisie : ils doivent être identifiés par le service maintenance.",
            f"R(t) estimée à {r * 100:.2f} % pour {t:g} h ; MTBF = {mtbf:.6g} h."))

    if r_crit:
        recs.append(Recommandation(
            "REDONDANCE", Priorite.HAUTE,
            "Pour cette mission, prévoir une redondance (équipement de secours) ou "
            "un plan de repli, ou raccourcir la durée de mission.",
            f"Risque estimé de {(1 - r) * 100:.2f} % d'au moins une défaillance "
            f"pendant {t:g} h."))

    if m_crit or m_bas or ratio_haut:
        motifs = []
        if m is not None and m_bas:
            motifs.append(f"M(t) = {m * 100:.2f} %")
        if ratio_haut:
            motifs.append(f"MTTR/MTBF = {mttr / mtbf * 100:.2f} %")
        recs.append(Recommandation(
            "REDUIRE_MTTR", Priorite.HAUTE if m_crit else Priorite.MOYENNE,
            "Réduire la durée des réparations : procédures d'intervention "
            "standardisées, pièces critiques disponibles, outillage et compétences "
            "adaptés, préparation des interventions.",
            " ; ".join(motifs) + "."))

    if attente_haute:
        recs.append(Recommandation(
            "LOGISTIQUE", Priorite.MOYENNE,
            "Identifier la nature des arrêts hors réparation, puis réduire les "
            "attentes : stock de pièces critiques, astreinte, processus de "
            "diagnostic et d'approbation.",
            f"{attente:g} h sur {tarr:g} h d'arrêt ({part_attente * 100:.1f} %) "
            "ne sont pas du temps de réparation."))

    if faible_echantillon:
        recs.append(Recommandation(
            "DONNEES", Priorite.MOYENNE,
            "Poursuivre la collecte des données et recalculer avant de décider "
            "d'actions lourdes ou coûteuses.",
            f"Seulement {n} défaillance(s) observée(s)."))

    if extrapolation:
        recs.append(Recommandation(
            "EXTRAPOLATION", Priorite.MOYENNE,
            "Recalculer la fiabilité lorsque le temps de fonctionnement cumulé "
            "atteindra la durée de mission, ou utiliser une mission plus courte.",
            f"Mission de {t:g} h pour {top:g} h de fonctionnement observé."))

    if n > 0:
        recs.append(Recommandation(
            "WEIBULL_DONNEES",
            Priorite.MOYENNE if (r_crit or r_att) else Priorite.FAIBLE,
            "Si une analyse plus fine est souhaitée (hors de cet outil), enregistrer "
            "les durées entre défaillances successives pour ajuster une loi de "
            "Weibull : elle seule indique si l'équipement s'use (β > 1), se dégrade "
            "en début de vie (β < 1) ou tombe en panne de façon aléatoire (β ≈ 1), "
            "et justifie ou non une maintenance préventive systématique.",
            "Sous l'hypothèse exponentielle utilisée ici, un remplacement "
            "systématique à âge fixe n'apporterait aucun gain : cette hypothèse "
            "n'est pas vérifiable avec la saisie globale."))
        if not any(x.priorite is not Priorite.FAIBLE for x in recs):
            recs.append(Recommandation(
                "MAINTENIR", Priorite.FAIBLE,
                "Maintenir le plan de maintenance actuel et suivre les indicateurs "
                "périodiquement.",
                "Aucun indicateur ne dépasse un seuil d'alerte indicatif."))
    else:
        recs.append(Recommandation(
            "SURVEILLANCE", Priorite.FAIBLE,
            "Maintenir la surveillance, enregistrer toute défaillance dès qu'elle "
            "survient et recalculer. Ne pas conclure à l'absence de risque.",
            f"Aucune défaillance sur {top:g} h : fiabilité non évaluable."))

    recs.sort(key=lambda x: x.priorite.value)  # tri stable

    # ------------------------------------------------------------- Synthèse
    niveaux = [c.niveau for c in constats if c.niveau is not Niveau.INFO]
    pire = max(niveaux, key=_RANG.get, default=Niveau.INFO)
    if r is None:
        if pire is Niveau.BON:
            pire = Niveau.INFO
            synthese = ("Disponibilité satisfaisante, mais la fiabilité n'est pas "
                        "évaluable : aucune défaillance n'a été observée.")
        else:
            synthese = (SYNTHESES[pire] + " La fiabilité n'est pas évaluable "
                        "(aucune défaillance observée).")
    else:
        synthese = SYNTHESES[pire]

    return Interpretation(pire, synthese, constats, recs)