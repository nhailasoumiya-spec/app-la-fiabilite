"""Formules LaTeX et mise en forme des résultats pour l'affichage."""
from .models import Indicator

LATEX = {
    "MTBF": r"MTBF = \frac{T_{\text{fonct}}}{N}",
    "MTTR": r"MTTR = \frac{T_{\text{rép}}}{N}",
    "LAMBDA": r"\lambda = \frac{N}{T_{\text{fonct}}}",
    "MU": r"\mu = \frac{N}{T_{\text{rép}}} = \frac{1}{MTTR}",
    "DISPO_OBS": r"A = \frac{T_{\text{fonct}}}{T_{\text{fonct}} + T_{\text{arrêt}}}",
    "DISPO_INTR": r"A_i = \frac{MTBF}{MTBF + MTTR}",
    "R": r"R(t) = e^{-\lambda \, t}",
    "M": r"M(t) = 1 - e^{-\mu \, t}",
}

# Indicateurs sans unité, affichés aussi en pourcentage
ADIMENSIONNELS = {"DISPO_OBS", "DISPO_INTR", "R", "M"}

LEGENDE_VARIABLES = (
    "**N** : nombre de défaillances · "
    "**T_fonct** : temps total de fonctionnement (h) · "
    "**T_arrêt** : temps total d'arrêt (h) · "
    "**T_rép** : temps total de réparation (h) · "
    "**t** : durée de mission (h)"
)


def format_valeur(ind: Indicator) -> str:
    if ind.valeur is None:
        return "Non calculable"
    if ind.code in ADIMENSIONNELS:
        return f"{ind.valeur:.6f}  ({ind.valeur * 100:.3f} %)"
    return f"{ind.valeur:.6g} {ind.unite}".strip()


def badge_nature(ind: Indicator) -> str:
    return "🟦 Calculé" if ind.nature.name == "CALCULE" else "🟨 Estimé (modèle exponentiel)"