"""Moteur de calcul : aucune dépendance à Streamlit."""
import math
from typing import Optional

from .models import EquipmentInput, Indicator, Nature, Resultats, ValidationReport
from .validation import valider

NOTE_WEIBULL = (
    "Paramètres de Weibull (β, η) non calculés : ils exigent les durées entre "
    "défaillances successives, absentes de la saisie globale. "
    "Hypothèse retenue : taux de défaillance constant (β = 1)."
)


class DonneesInvalidesError(ValueError):
    def __init__(self, rapport: ValidationReport):
        self.rapport = rapport
        super().__init__(" | ".join(rapport.erreurs))


def _f(x: float) -> str:
    """Format compact pour l'affichage des valeurs numériques."""
    return f"{x:.6g}"


def _impossible(code, libelle, unite, nature, formule, raison) -> Indicator:
    return Indicator(code, libelle, None, unite, nature, formule,
                     "Calcul impossible", raison)


def calculer(d: EquipmentInput) -> Resultats:
    rapport = valider(d)
    if not rapport.ok:
        raise DonneesInvalidesError(rapport)

    n = int(d.nb_defaillances)
    top = float(d.temps_fonctionnement_h)
    tarr = float(d.temps_arret_h)
    trep = float(d.temps_reparation_h)
    t = float(d.duree_mission_h)
    ind: dict[str, Indicator] = {}

    # --- MTBF ---
    if n > 0:
        mtbf: Optional[float] = top / n
        ind["MTBF"] = Indicator(
            "MTBF", "Temps moyen entre défaillances", mtbf, "h", Nature.CALCULE,
            "MTBF = T_fonct / N",
            f"MTBF = {_f(top)} / {n} = {_f(mtbf)} h")
    else:
        mtbf = None
        ind["MTBF"] = _impossible(
            "MTBF", "Temps moyen entre défaillances", "h", Nature.CALCULE,
            "MTBF = T_fonct / N", "Division par N = 0 : aucune défaillance observée.")

    # --- MTTR ---
    if n > 0:
        mttr: Optional[float] = trep / n
        ind["MTTR"] = Indicator(
            "MTTR", "Temps moyen de réparation", mttr, "h", Nature.CALCULE,
            "MTTR = T_rép / N",
            f"MTTR = {_f(trep)} / {n} = {_f(mttr)} h",
            "Temps de réparation nul : à vérifier." if trep == 0 else "")
    else:
        mttr = None
        ind["MTTR"] = _impossible(
            "MTTR", "Temps moyen de réparation", "h", Nature.CALCULE,
            "MTTR = T_rép / N", "Division par N = 0 : aucune réparation à moyenner.")

    # --- Taux de défaillance λ ---
    lam = n / top
    ind["LAMBDA"] = Indicator(
        "LAMBDA", "Taux de défaillance", lam, "1/h", Nature.CALCULE,
        "λ = N / T_fonct",
        f"λ = {n} / {_f(top)} = {_f(lam)} 1/h",
        "Valeur moyenne observée. λ = 0 ne prouve pas l'absence de défaillance."
        if n == 0 else "")

    # --- Taux de réparation μ ---
    if n > 0 and trep > 0:
        mu: Optional[float] = n / trep
        ind["MU"] = Indicator(
            "MU", "Taux de réparation", mu, "1/h", Nature.CALCULE,
            "μ = N / T_rép = 1 / MTTR",
            f"μ = {n} / {_f(trep)} = {_f(mu)} 1/h")
    else:
        mu = None
        raison = ("Aucune défaillance." if n == 0
                  else "Temps de réparation nul : division par zéro.")
        ind["MU"] = _impossible("MU", "Taux de réparation", "1/h", Nature.CALCULE,
                                "μ = N / T_rép = 1 / MTTR", raison)

    # --- Disponibilités ---
    a_obs = top / (top + tarr)
    ind["DISPO_OBS"] = Indicator(
        "DISPO_OBS", "Disponibilité observée", a_obs, "", Nature.CALCULE,
        "A = T_fonct / (T_fonct + T_arrêt)",
        f"A = {_f(top)} / ({_f(top)} + {_f(tarr)}) = {_f(a_obs)} "
        f"({_f(a_obs * 100)} %)",
        "Suppose que T_fonct + T_arrêt représente le temps calendaire observé.")

    if mtbf is not None and mttr is not None:
        a_int = mtbf / (mtbf + mttr)
        ind["DISPO_INTR"] = Indicator(
            "DISPO_INTR", "Disponibilité intrinsèque", a_int, "", Nature.CALCULE,
            "A_i = MTBF / (MTBF + MTTR)",
            f"A_i = {_f(mtbf)} / ({_f(mtbf)} + {_f(mttr)}) = {_f(a_int)} "
            f"({_f(a_int * 100)} %)",
            "Ne tient compte que du temps de réparation (hors attentes logistiques).")
    else:
        ind["DISPO_INTR"] = _impossible(
            "DISPO_INTR", "Disponibilité intrinsèque", "", Nature.CALCULE,
            "A_i = MTBF / (MTBF + MTTR)", "MTBF et MTTR non calculables (N = 0).")

    # --- Fiabilité R(t) ---
    if n > 0:
        r = math.exp(-lam * t)
        ind["R"] = Indicator(
            "R", f"Fiabilité R(t) pour t = {_f(t)} h", r, "", Nature.ESTIME,
            "R(t) = exp(−λ · t)",
            f"R({_f(t)}) = exp(−{_f(lam)} × {_f(t)}) = {_f(r)} ({_f(r * 100)} %)",
            "Estimation valable si le taux de défaillance est constant.")
    else:
        ind["R"] = _impossible(
            "R", f"Fiabilité R(t) pour t = {_f(t)} h", "", Nature.ESTIME,
            "R(t) = exp(−λ · t)",
            "Aucune défaillance observée : estimation non significative (R = 1 serait trompeur).")

    # --- Maintenabilité M(t) ---
    if mu is not None:
        m = 1.0 - math.exp(-mu * t)
        ind["M"] = Indicator(
            "M", f"Maintenabilité M(t) pour t = {_f(t)} h", m, "", Nature.ESTIME,
            "M(t) = 1 − exp(−μ · t)",
            f"M({_f(t)}) = 1 − exp(−{_f(mu)} × {_f(t)}) = {_f(m)} ({_f(m * 100)} %)",
            "Probabilité de terminer une réparation en t heures, "
            "si la durée de réparation suit une loi exponentielle.")
    else:
        ind["M"] = _impossible(
            "M", f"Maintenabilité M(t) pour t = {_f(t)} h", "", Nature.ESTIME,
            "M(t) = 1 − exp(−μ · t)", "μ non calculable.")

    return Resultats(d, ind, rapport.avertissements, NOTE_WEIBULL)