"""Structures de données du projet."""
from dataclasses import dataclass
from enum import Enum
from typing import Optional


class Nature(str, Enum):
    """Distingue un résultat calculé d'une estimation basée sur un modèle."""
    CALCULE = "Calculé"
    ESTIME = "Estimé (modèle exponentiel)"


@dataclass(frozen=True)
class EquipmentInput:
    """Données saisies par l'utilisateur (valeurs globales uniquement)."""
    nom: str
    nb_defaillances: int
    temps_fonctionnement_h: float
    temps_arret_h: float
    temps_reparation_h: float
    duree_mission_h: float


@dataclass
class Indicator:
    """Un indicateur de fiabilité avec sa traçabilité."""
    code: str                 # ex. "MTBF"
    libelle: str              # ex. "Temps moyen entre défaillances"
    valeur: Optional[float]   # None = calcul impossible
    unite: str                # ex. "h", "1/h", "" (sans unité)
    nature: Nature
    formule: str              # formule littérale
    formule_numerique: str    # variables remplacées par les valeurs saisies
    remarque: str = ""

    @property
    def calculable(self) -> bool:
        return self.valeur is not None


@dataclass
class ValidationReport:
    erreurs: list[str]
    avertissements: list[str]

    @property
    def ok(self) -> bool:
        return not self.erreurs


@dataclass
class Resultats:
    donnees: EquipmentInput
    indicateurs: dict[str, Indicator]
    avertissements: list[str]
    note_weibull: str