import math

from fiabilite.calculations import calculer
from fiabilite.interpretation import Niveau, Priorite, Seuils, interpreter
from fiabilite.models import EquipmentInput


def make(**kw):
    base = dict(nom="Test", nb_defaillances=4, temps_fonctionnement_h=2000,
                temps_arret_h=60, temps_reparation_h=40, duree_mission_h=100)
    base.update(kw)
    return EquipmentInput(**base)


def codes(items):
    return {i.code for i in items}


def test_cas_nominal():
    it = interpreter(calculer(make()))
    c = {x.code: x for x in it.constats}
    assert c["DISPO"].niveau is Niveau.ATTENTION       # 97,09 %
    assert c["FIAB"].niveau is Niveau.ATTENTION        # 81,87 %
    assert c["MAINT"].niveau is Niveau.BON
    assert c["RATIO"].niveau is Niveau.BON
    assert c["ATTENTE"].niveau is Niveau.ATTENTION     # 20 h sur 60 h
    assert c["ECHANTILLON"].niveau is Niveau.ATTENTION
    assert "EXTRAPOLATION" not in c
    assert it.niveau_global is Niveau.ATTENTION
    assert all(r.priorite is not Priorite.HAUTE for r in it.recommandations)
    assert {"LOGISTIQUE", "DONNEES", "WEIBULL_DONNEES",
            "ANALYSE_CAUSES"} <= codes(it.recommandations)


def test_zero_defaillance():
    it = interpreter(calculer(make(nb_defaillances=0, temps_reparation_h=0)))
    c = {x.code: x for x in it.constats}
    assert "ZERO_DEFAILLANCE" in c
    assert not ({"FIAB", "MAINT", "RATIO"} & set(c))
    lam_sup = -math.log(0.05) / 2000
    assert f"{lam_sup:.6g}" in c["ZERO_DEFAILLANCE"].texte
    rec = codes(it.recommandations)
    assert "SURVEILLANCE" in rec
    assert "ANALYSE_CAUSES" not in rec
    assert "fiabilité n'est pas évaluable" in it.synthese.lower()


def test_zero_defaillance_bonne_disponibilite_reste_info():
    it = interpreter(calculer(make(nb_defaillances=0, temps_arret_h=0,
                                   temps_reparation_h=0)))
    assert it.niveau_global is Niveau.INFO


def test_equipement_mauvais():
    it = interpreter(calculer(make(nb_defaillances=50, temps_fonctionnement_h=1000,
                                   temps_arret_h=300, temps_reparation_h=250)))
    c = {x.code: x for x in it.constats}
    assert c["FIAB"].niveau is Niveau.CRITIQUE
    assert c["DISPO"].niveau is Niveau.CRITIQUE
    assert c["RATIO"].niveau is Niveau.ATTENTION
    assert it.niveau_global is Niveau.CRITIQUE
    hautes = {r.code for r in it.recommandations if r.priorite is Priorite.HAUTE}
    assert {"ANALYSE_CAUSES", "REDONDANCE", "PRIORISER"} <= hautes
    assert "REDUIRE_MTTR" in codes(it.recommandations)
    prios = [r.priorite.value for r in it.recommandations]
    assert prios == sorted(prios)


def test_equipement_bon():
    it = interpreter(calculer(make(nb_defaillances=10, temps_fonctionnement_h=10000,
                                   temps_arret_h=50, temps_reparation_h=45,
                                   duree_mission_h=24)))
    assert it.niveau_global is Niveau.BON
    assert "MAINTENIR" in codes(it.recommandations)
    assert all(r.priorite is Priorite.FAIBLE for r in it.recommandations)


def test_extrapolation():
    it = interpreter(calculer(make(duree_mission_h=5000)))
    assert "EXTRAPOLATION" in codes(it.constats)
    assert "EXTRAPOLATION" in codes(it.recommandations)


def test_reparation_nulle():
    it = interpreter(calculer(make(temps_reparation_h=0)))
    c = {x.code: x for x in it.constats}
    assert c["MAINT"].niveau is Niveau.INFO
    assert "RATIO" not in c


def test_seuils_personnalises():
    it = interpreter(calculer(make()), Seuils(dispo_elevee=0.95))
    c = {x.code: x for x in it.constats}
    assert c["DISPO"].niveau is Niveau.BON


def test_textes_non_vides():
    it = interpreter(calculer(make()))
    assert it.synthese and it.avertissement
    for c in it.constats:
        assert c.titre and c.texte
    for r in it.recommandations:
        assert r.action and r.justification