import numpy as np
import pytest

from fiabilite.calculations import calculer
from fiabilite.curves import (disponibilite, fiabilite, figure_comparatif,
                              figure_disponibilite, figure_fiabilite,
                              figure_maintenabilite, maintenabilite)
from fiabilite.models import EquipmentInput


def make(**kw):
    base = dict(nom="Test", nb_defaillances=4, temps_fonctionnement_h=2000,
                temps_arret_h=60, temps_reparation_h=40, duree_mission_h=100)
    base.update(kw)
    return EquipmentInput(**base)


def test_fiabilite_bornes():
    r = fiabilite(0.002, np.array([0.0, 500.0]))
    assert r[0] == pytest.approx(1.0)
    assert r[1] == pytest.approx(np.exp(-1))


def test_maintenabilite_bornes():
    m = maintenabilite(0.1, np.array([0.0, 10.0]))
    assert m[0] == pytest.approx(0.0)
    assert m[1] == pytest.approx(1 - np.exp(-1))


def test_disponibilite_bornes():
    a = disponibilite(0.002, 0.1, np.array([0.0, 1e6]))
    assert a[0] == pytest.approx(1.0)
    assert a[1] == pytest.approx(0.1 / 0.102)


def test_asymptote_egale_disponibilite_intrinseque():
    res = calculer(make())
    lam, mu = res.indicateurs["LAMBDA"].valeur, res.indicateurs["MU"].valeur
    assert mu / (lam + mu) == pytest.approx(res.indicateurs["DISPO_INTR"].valeur)


@pytest.mark.parametrize("f", [figure_fiabilite, figure_disponibilite,
                               figure_maintenabilite])
def test_courbes_nominales(f):
    fig, msg = f(calculer(make()))
    assert fig is not None and msg == ""


def test_comparatif_nominal():
    fig, msg = figure_comparatif(calculer(make()))
    assert fig is not None and msg == ""


@pytest.mark.parametrize("f", [figure_fiabilite, figure_disponibilite,
                               figure_maintenabilite])
def test_courbes_impossibles_sans_defaillance(f):
    res = calculer(make(nb_defaillances=0, temps_reparation_h=0))
    fig, msg = f(res)
    assert fig is None and msg


def test_reparation_nulle():
    res = calculer(make(temps_reparation_h=0))
    assert figure_fiabilite(res)[0] is not None
    assert figure_disponibilite(res)[0] is None
    assert figure_maintenabilite(res)[0] is None
    assert figure_comparatif(res)[0] is not None


def test_comparatif_sans_defaillance():
    res = calculer(make(nb_defaillances=0, temps_reparation_h=0))
    assert figure_comparatif(res)[0] is not None


def test_zoom_invalide():
    with pytest.raises(ValueError):
        figure_fiabilite(calculer(make()), zoom=0)