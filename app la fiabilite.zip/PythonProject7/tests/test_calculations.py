import pytest

from fiabilite.calculations import DonneesInvalidesError, calculer
from fiabilite.models import EquipmentInput, Nature


def make(**kw):
    base = dict(nom="Test", nb_defaillances=4, temps_fonctionnement_h=2000,
                temps_arret_h=60, temps_reparation_h=40, duree_mission_h=100)
    base.update(kw)
    return EquipmentInput(**base)


def test_valeurs_nominales():
    r = calculer(make()).indicateurs
    assert r["MTBF"].valeur == pytest.approx(500)
    assert r["MTTR"].valeur == pytest.approx(10)
    assert r["LAMBDA"].valeur == pytest.approx(0.002)
    assert r["MU"].valeur == pytest.approx(0.1)
    assert r["R"].valeur == pytest.approx(0.8187308, rel=1e-6)
    assert r["M"].valeur == pytest.approx(0.9999546, rel=1e-6)
    assert r["DISPO_OBS"].valeur == pytest.approx(2000 / 2060)
    assert r["DISPO_INTR"].valeur == pytest.approx(500 / 510)


def test_natures():
    r = calculer(make()).indicateurs
    assert r["MTBF"].nature == Nature.CALCULE
    assert r["R"].nature == Nature.ESTIME
    assert r["M"].nature == Nature.ESTIME


def test_zero_defaillance():
    res = calculer(make(nb_defaillances=0, temps_reparation_h=0))
    for code in ("MTBF", "MTTR", "MU", "R", "M", "DISPO_INTR"):
        assert res.indicateurs[code].valeur is None
    assert res.indicateurs["LAMBDA"].valeur == 0
    assert res.indicateurs["DISPO_OBS"].valeur is not None
    assert res.avertissements


def test_reparation_nulle():
    r = calculer(make(temps_reparation_h=0)).indicateurs
    assert r["MTTR"].valeur == 0
    assert r["MU"].valeur is None
    assert r["M"].valeur is None


@pytest.mark.parametrize("champ,val", [
    ("temps_fonctionnement_h", 0),
    ("temps_fonctionnement_h", -5),
    ("nb_defaillances", -1),
    ("nb_defaillances", 2.5),
    ("temps_arret_h", -1),
    ("duree_mission_h", 0),
    ("temps_reparation_h", 70),       # > temps d'arrêt (60)
    ("nom", "  "),
    ("duree_mission_h", float("nan")),
])
def test_donnees_invalides(champ, val):
    with pytest.raises(DonneesInvalidesError):
        calculer(make(**{champ: val}))


def test_extrapolation_signalee():
    res = calculer(make(duree_mission_h=5000))
    assert any("extrapolation" in w for w in res.avertissements)


def test_faible_echantillon_signale():
    res = calculer(make(nb_defaillances=2, temps_reparation_h=20))
    assert any("fragiles" in w for w in res.avertissements)