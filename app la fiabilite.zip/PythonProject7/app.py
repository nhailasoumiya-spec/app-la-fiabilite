"""Application Streamlit : calcul de fiabilité d'équipements industriels."""
import pandas as pd
import streamlit as st

from fiabilite.calculations import DonneesInvalidesError, calculer
from fiabilite.curves import (figure_comparatif, figure_disponibilite,
                              figure_fiabilite, figure_maintenabilite)
from fiabilite.formatting import LATEX, LEGENDE_VARIABLES, badge_nature, format_valeur
from fiabilite.interpretation import (ICONES, LIBELLE_PRIORITE, Niveau, Seuils,
                                      interpreter)
from fiabilite.models import EquipmentInput

st.set_page_config(page_title="Fiabilité des équipements", page_icon="🛠️", layout="wide")

st.title("🛠️ Calcul de fiabilité des équipements industriels")
st.caption("Saisissez uniquement des valeurs globales : aucun historique de pannes n'est nécessaire.")


def afficher_figure(resultat_figure, legende: str) -> None:
    fig, msg = resultat_figure
    if fig is None:
        st.info(f"Courbe non disponible : {msg}")
    else:
        st.pyplot(fig)
        st.caption(legende)


# ------------------------------------------------------------------ Saisie
with st.form("formulaire"):
    nom = st.text_input("Nom de l'équipement", placeholder="Ex. : Pompe P-101")

    c1, c2 = st.columns(2)
    with c1:
        nb = st.number_input("Nombre total de défaillances", value=None, step=1,
                             format="%d", placeholder="Entier ≥ 0")
        t_fonct = st.number_input("Temps total de fonctionnement (h)", value=None,
                                  step=1.0, placeholder="Heures > 0")
        t_arret = st.number_input("Temps total d'arrêt (h)", value=None,
                                  step=1.0, placeholder="Heures ≥ 0")
    with c2:
        t_rep = st.number_input("Temps total de réparation (h)", value=None,
                                step=1.0, placeholder="Heures ≥ 0 (inclus dans l'arrêt)")
        t_mission = st.number_input("Durée de mission t (h)", value=None,
                                    step=1.0, placeholder="Heures > 0")

    valide = st.form_submit_button("Calculer", type="primary")

# ------------------------------------------------------------------ Calcul
if valide:
    donnees = EquipmentInput(
        nom=nom,
        nb_defaillances=nb,
        temps_fonctionnement_h=t_fonct,
        temps_arret_h=t_arret,
        temps_reparation_h=t_rep,
        duree_mission_h=t_mission,
    )
    try:
        st.session_state["resultats"] = calculer(donnees)
        st.session_state["erreurs"] = None
    except DonneesInvalidesError as e:
        st.session_state["resultats"] = None
        st.session_state["erreurs"] = e.rapport.erreurs

# ------------------------------------------------------------------ Affichage
erreurs = st.session_state.get("erreurs")
res = st.session_state.get("resultats")

if erreurs:
    st.error("Calcul impossible : corrigez les points suivants.")
    for msg in erreurs:
        st.markdown(f"- ❌ {msg}")

if res:
    st.header(f"Résultats : {res.donnees.nom.strip()}")

    for w in res.avertissements:
        st.warning(w)

    ind = res.indicateurs

    # --- Indicateurs clés
    cles = ["MTBF", "MTTR", "LAMBDA", "MU"]
    cols = st.columns(len(cles))
    for col, code in zip(cols, cles):
        col.metric(code, format_valeur(ind[code]))

    cles2 = ["DISPO_OBS", "DISPO_INTR", "R", "M"]
    cols2 = st.columns(len(cles2))
    for col, code in zip(cols2, cles2):
        i = ind[code]
        affichage = "Non calculable" if i.valeur is None else f"{i.valeur * 100:.3f} %"
        col.metric(i.libelle, affichage)

    # --- Tableau récapitulatif
    st.subheader("Tableau récapitulatif")
    tableau = pd.DataFrame([
        {
            "Indicateur": i.libelle,
            "Valeur": format_valeur(i),
            "Unité": i.unite if i.unite else "sans unité",
            "Nature": badge_nature(i),
        }
        for i in ind.values()
    ])
    st.dataframe(tableau, hide_index=True)
    st.caption("🟦 Calculé : déduit directement des valeurs saisies. "
               "🟨 Estimé : repose sur l'hypothèse d'un taux constant (loi exponentielle).")

    # --- Courbes
    st.subheader("Courbes et graphique comparatif")
    zoom = st.slider("Zoom sur l'axe du temps (× horizon par défaut)",
                     min_value=0.25, max_value=5.0, value=1.0, step=0.25, key="zoom")
    tab_r, tab_a, tab_m, tab_c = st.tabs(
        ["Fiabilité R(t)", "Disponibilité A(t)", "Maintenabilité M(t)", "Comparatif"])

    with tab_r:
        afficher_figure(
            figure_fiabilite(res, zoom),
            "🟨 Estimation : suppose un taux de défaillance constant. "
            "La zone grisée dépasse le temps de fonctionnement observé (extrapolation).")
    with tab_a:
        afficher_figure(
            figure_disponibilite(res, zoom),
            "🟨 Estimation : modèle à deux états (marche / réparation), "
            "avec l'équipement en marche à t = 0.")
    with tab_m:
        afficher_figure(
            figure_maintenabilite(res, zoom),
            "🟨 Estimation : suppose une durée de réparation de loi exponentielle. "
            "La même durée t que la mission est utilisée.")
    with tab_c:
        afficher_figure(
            figure_comparatif(res),
            "Barres pleines : indicateurs calculés. Barres hachurées : estimations.")

    # --- Interprétation technique
    interp = interpreter(res)

    st.subheader("Interprétation technique automatique")
    message = f"**{interp.niveau_global.value}** : {interp.synthese}"
    {
        Niveau.CRITIQUE: st.error,
        Niveau.ATTENTION: st.warning,
        Niveau.BON: st.success,
        Niveau.INFO: st.info,
    }[interp.niveau_global](message)

    for c in interp.constats:
        with st.container(border=True):
            st.markdown(f"{ICONES[c.niveau]} **{c.titre}** · *{c.nature}*")
            st.write(c.texte)

    # --- Recommandations
    st.subheader("Recommandations de maintenance")
    for rec in interp.recommandations:
        with st.container(border=True):
            st.markdown(f"**{LIBELLE_PRIORITE[rec.priorite]}** : {rec.action}")
            st.caption(f"Pourquoi : {rec.justification}")
    st.caption(interp.avertissement)

    with st.expander("Seuils indicatifs utilisés pour l'interprétation"):
        st.dataframe(pd.DataFrame(Seuils().lignes(), columns=["Critère", "Règle appliquée"]),
                     hide_index=True)
        st.caption("Conventions de pratique, sans valeur normative : à adapter "
                   "au contexte de l'entreprise et à la criticité de l'équipement.")

    # --- Détail des formules
    st.subheader("Formules et remplacement des variables")
    st.markdown(LEGENDE_VARIABLES)
    for code, i in ind.items():
        with st.expander(f"{i.libelle}  ·  {badge_nature(i)}", expanded=False):
            st.latex(LATEX[code])
            st.markdown("**Application numérique :**")
            st.code(i.formule_numerique, language=None)
            st.markdown(f"**Résultat :** {format_valeur(i)}")
            if i.remarque:
                st.info(i.remarque)

    # --- Weibull
    st.subheader("Paramètres de Weibull")
    st.info(res.note_weibull)

    st.divider()
    st.caption("À venir : export PDF et Excel (étape 5).")